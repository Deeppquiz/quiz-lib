import '../scss/style.scss'
window.Vue = require('vue');
import Vue from 'vue';

